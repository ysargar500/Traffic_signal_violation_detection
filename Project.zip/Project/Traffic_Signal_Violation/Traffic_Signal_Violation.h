// include the library code:
#include <LiquidCrystal.h>
#include <stdlib.h>

#define   IR1       A1
#define   IR2       A2
#define   RED_SIG   9
#define   YEL_SIG   10
#define   GRN_SIG   11
#define   ESP_CAM   8

#define   IR_1_1  digitalRead(IR1)
#define   IR_2_1  digitalRead(IR2)

#define LCD_RS    2
#define LCD_EN    3
#define LCD_D4    4
#define LCD_D5    5
#define LCD_D6    6
#define LCD_D7    7
LiquidCrystal lcd(LCD_RS, LCD_EN, LCD_D4, LCD_D5, LCD_D6, LCD_D7);

int sw1 = 4, sw2 = 5;
int LED = 13;
const int Mot1A = A2, Mot1B = A3, Mot2A = A1;//, Mot2B = A5;
const int BUZZ = 12, RELAY = 11;
//#define LDR2      A1


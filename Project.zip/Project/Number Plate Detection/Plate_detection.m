close all;
clear all;

% Focal length about 15cm from camera
% Working numbers:
% MH09NE0555
% MH09EF9876
% MH10XY6543
% MH02FH8520
% MH02LM2596
% MH12KG1472
% MH12GB3692
while true
    resp = urlread('http://192.168.43.180/getimg');
    pause(0.5);
    if strcmp(resp, 'Captured')
        close all;
        clear all;
        url = 'http://192.168.43.180/saved-photo/photo.jpg';
        im  = imread(url);
        figure('Units','normalized','Position',[0 0 1 1]);
        imshow(im);     % Show original image

        imgray = rgb2gray(im);  % colour to gray conversion

        imbin = im2bw(imgray,0.5);  % Threshold range: 0 to 1
        figure('Units','normalized','Position',[0 0 1 1]);
        imshow(imbin);

        im = edge(imgray, 'prewitt');
        figure('Units','normalized','Position',[0 0 1 1]);
        imshow(im);

        se = strel('disk',1);
        im = imclose(im,se);        % Morphologically close image

        %Below steps are to find location of number plate
        Iprops=regionprops(im,'BoundingBox','Area', 'Image');
        area = Iprops.Area;
        count = numel(Iprops);
        maxa = area;
        boundingBox = Iprops.BoundingBox;
        for i=1:count
           if maxa<Iprops(i).Area
               maxa=Iprops(i).Area;
               boundingBox=Iprops(i).BoundingBox;
           end
        end    

        im = imcrop(imbin, boundingBox);%crop the number plate area
        im = bwareaopen(~im, 500); %remove some object if it width is too long or too small than 500

        [h, w] = size(im);%get width

        figure('Units','normalized','Position',[0 0 1 1]);
        imshow(im);

        Iprops=regionprops(im,'BoundingBox','Area', 'Image'); %read letter
        count = numel(Iprops);
        noPlate=[]; % Initializing the variable of number plate string.

        for i=1:count
           ow = length(Iprops(i).Image(1,:));
           oh = length(Iprops(i).Image(:,1));
           if ow<(h/2) & oh>(h/3)
               letter=Letter_detection(Iprops(i).Image); % Reading the letter corresponding the binary image 'N'.
               noPlate = [noPlate letter]; % Appending every subsequent character in noPlate variable.
           end

        end
        noPlate = strrep(noPlate,'I','1');
        noPlate = strrep(noPlate,'S','5')
        updateNoUrl = strcat('http://192.168.43.180/update?VehicleNum=', noPlate);
        urlread(updateNoUrl)
        
    end
end

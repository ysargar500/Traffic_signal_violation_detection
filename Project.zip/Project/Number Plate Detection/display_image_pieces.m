%subplot(3,4,1);
for i=1:11
    subplot(3,4,i);
    imshow(Iprops(i).Image);
end